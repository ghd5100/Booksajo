package com.tech.booksajo.main.service;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;


public interface mainService  {
	
	List<Map<String,Object>> getList();
	
}
