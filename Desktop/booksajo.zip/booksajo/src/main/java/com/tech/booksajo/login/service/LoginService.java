package com.tech.booksajo.login.service;

import java.util.List;
import java.util.Map;


public interface LoginService  {
	
	List<Map<String,Object>> getList();

}

