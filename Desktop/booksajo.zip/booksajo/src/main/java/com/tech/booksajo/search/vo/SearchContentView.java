package com.tech.booksajo.search.vo;

public class SearchContentView {
/*서치해서 상세페이지부분에 필요한 테이블 필드명들*/
}
