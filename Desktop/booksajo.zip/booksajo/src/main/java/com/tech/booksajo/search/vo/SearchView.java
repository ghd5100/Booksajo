package com.tech.booksajo.search.vo;

public class SearchView {
//서치할떄 필요한 테이블 필드들
	
}
