package com.tech.booksajo.faq.service;

import java.util.List;
import java.util.Map;


public interface FaqService  {
	
	List<Map<String,Object>> getList();

}