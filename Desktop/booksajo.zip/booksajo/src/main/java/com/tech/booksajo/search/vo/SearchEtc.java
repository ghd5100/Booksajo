package com.tech.booksajo.search.vo;

public class SearchEtc {
/*기타 서치페이지에서 추가로 필요한 것 임시이름정함*/ 
	
}
